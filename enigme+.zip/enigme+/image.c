#include "image.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int load_assets(GameAssets *assets) {
    char puzzle_name[20];
    char prop_name[20];
    char complete_name[20];

    // Initialiser les puzzles
    for (int i = 0; i < 5; i++) {
        snprintf(puzzle_name, sizeof(puzzle_name), "puzzle%d.png", i + 1);
        assets->puzzles[i].img = IMG_Load(puzzle_name);
        if (!assets->puzzles[i].img) {
            printf("Erreur chargement %s: %s\n", puzzle_name, IMG_GetError());
            return 0;
        }
        assets->puzzles[i].pos.x = 82;
        assets->puzzles[i].pos.y = 202;
        assets->puzzles[i].pos.w = assets->puzzles[i].img->w;
        assets->puzzles[i].pos.h = assets->puzzles[i].img->h;
        assets->puzzles[i].isHovered = 0;
        assets->puzzles[i].is_selected = 0;
    }

    // Initialiser les images complètes (puzzleXc.png)
    for (int i = 0; i < 5; i++) {
        snprintf(complete_name, sizeof(complete_name), "puzzle%dc.png", i + 1);
        assets->complete_puzzles[i].img = IMG_Load(complete_name);
        if (!assets->complete_puzzles[i].img) {
            printf("Erreur chargement %s: %s\n", complete_name, IMG_GetError());
            return 0;
        }
        assets->complete_puzzles[i].pos.x = 82;
        assets->complete_puzzles[i].pos.y = 202;
        assets->complete_puzzles[i].pos.w = assets->complete_puzzles[i].img->w;
        assets->complete_puzzles[i].pos.h = assets->complete_puzzles[i].img->h;
        assets->complete_puzzles[i].isHovered = 0;
        assets->complete_puzzles[i].is_selected = 0;
    }

    // Initialiser les propositions : chaque puzzle a exactement 3 propositions
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            snprintf(prop_name, sizeof(prop_name), "p%d_%d.png", i + 1, j + 1);
            assets->propositions[i][j].img = IMG_Load(prop_name);
            if (!assets->propositions[i][j].img) {
                printf("Erreur chargement %s: %s\n", prop_name, IMG_GetError());
                return 0;
            }
            assets->propositions[i][j].pos.x = 1272;
            assets->propositions[i][j].pos.w = assets->propositions[i][j].img->w;
            assets->propositions[i][j].pos.h = assets->propositions[i][j].img->h;
            assets->propositions[i][j].isHovered = 0;
            assets->propositions[i][j].is_selected = 0;
        }
    }

    // Assigner les positions verticales des propositions (sera mélangé plus tard)
    for (int i = 0; i < 5; i++) {
        assets->propositions[i][0].pos.y = 209;
        assets->propositions[i][1].pos.y = 480;
        assets->propositions[i][2].pos.y = 783;
    }

    // Charger les images de fin
    assets->win.img = IMG_Load("win.png");
    assets->lose.img = IMG_Load("lose.png");
    assets->timeout.img = IMG_Load("timeout.png");
    assets->niveau1_2.img = IMG_Load("niveau1-2.png");
    assets->echouer.img = IMG_Load("echouer.png");

    if (!assets->win.img || !assets->lose.img || !assets->timeout.img ||
        !assets->niveau1_2.img || !assets->echouer.img) {
        printf("Erreur chargement images de fin: %s\n", IMG_GetError());
        return 0;
    }

    // Positionner les images de fin (centrées)
    assets->win.pos.x = 228;
    assets->win.pos.y = 47;
    assets->lose.pos.x = 238;
    assets->lose.pos.y = 456;
    assets->timeout.pos.x = 511;
    assets->timeout.pos.y = 387;
    assets->niveau1_2.pos.x = -40;
    assets->niveau1_2.pos.y = -40;
    assets->echouer.pos.x = 0;
    assets->echouer.pos.y = 0;

    // Initialiser la barre de progression
    assets->timer_bar.x = 30;
    assets->timer_bar.y = 30;
    assets->timer_bar.w = 1860;
    assets->timer_bar.h = 10;

    // Initialiser les puzzles utilisés
    for (int i = 0; i < 5; i++) {
        assets->used_puzzles[i] = 0;
    }
    assets->used_count = 0;
    assets->lose_count = 0;

    assets->game_over = 0;

    return 1;
}

void select_random_puzzle(GameAssets *assets) {
    // Si tous les puzzles ont été utilisés, réinitialiser la liste
    if (assets->used_count == 5) {
        for (int i = 0; i < 5; i++) {
            assets->used_puzzles[i] = 0;
        }
        assets->used_count = 0;
    }

    // Trouver les indices des puzzles non utilisés
    int available_puzzles[5];
    int available_count = 0;
    for (int i = 0; i < 5; i++) {
        if (!assets->used_puzzles[i]) {
            available_puzzles[available_count++] = i;
        }
    }

    // Choisir un puzzle aléatoire parmi les non utilisés
    int random_index = rand() % available_count;
    assets->current_puzzle = available_puzzles[random_index];
    assets->used_puzzles[assets->current_puzzle] = 1;
    assets->used_count++;

    // La proposition correcte est toujours pX_1.png, donc index 0
    assets->correct_proposition = 0;

    // Mélanger les positions verticales des propositions
    int positions[3] = {200, 550, 800}; // Positions y: haut, milieu, bas
    for (int i = 2; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = positions[i];
        positions[i] = positions[j];
        positions[j] = temp;
    }

    // Assigner les positions mélangées aux propositions
    for (int i = 0; i < 3; i++) {
        assets->propositions[assets->current_puzzle][i].pos.y = positions[i];
    }
}

void display_game(SDL_Surface *screen, GameAssets *assets) {
    // Calculer le temps écoulé
    float time_elapsed = (SDL_GetTicks() - assets->start_time) / 1000.0f;
    float total_time = 30.0f;
    float time_ratio = time_elapsed / total_time;
    if (time_ratio > 1.0f) time_ratio = 1.0f;

    // Effacer l'écran (fond noir)
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

    // Afficher la barre de progression
    if (!assets->game_over) {
        SDL_Rect current_bar = assets->timer_bar;
        current_bar.w = (int)(assets->timer_bar.w * (1.0f - time_ratio));
        Uint8 red = (Uint8)(255 * time_ratio);
        Uint8 green = (Uint8)(255 * (1.0f - time_ratio));
        SDL_FillRect(screen, &current_bar, SDL_MapRGB(screen->format, red, green, 0));
    }

    // Si le jeu est fini
    if (assets->game_over) {
        // Vérifier si 3 défaites ou timeouts
        if (assets->lose_count >= 3) {
            SDL_BlitSurface(assets->echouer.img, NULL, screen, &assets->echouer.pos);
            SDL_Flip(screen);
            SDL_Delay(4000);
        }
        // Vérifier si timeout (et moins de 3 défaites)
        else if (time_elapsed >= total_time) {
            SDL_BlitSurface(assets->timeout.img, NULL, screen, &assets->timeout.pos);
            SDL_Flip(screen);
            SDL_Delay(2000);
        }
        // Vérifier quelle proposition a été sélectionnée
        else {
            int correct = 0;
            for (int i = 0; i < 3; i++) {
                if (assets->propositions[assets->current_puzzle][i].is_selected) {
                    if (i == assets->correct_proposition) {
                        correct = 1;
                    }
                    break;
                }
            }
            if (correct) {
                SDL_BlitSurface(assets->complete_puzzles[assets->current_puzzle].img, NULL, screen, &assets->complete_puzzles[assets->current_puzzle].pos);
                SDL_BlitSurface(assets->win.img, NULL, screen, &assets->win.pos);
                SDL_Flip(screen);
                SDL_Delay(2000);
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
                SDL_BlitSurface(assets->niveau1_2.img, NULL, screen, &assets->niveau1_2.pos);
                SDL_Flip(screen);
                SDL_Delay(4000);
            } else {
                SDL_BlitSurface(assets->lose.img, NULL, screen, &assets->lose.pos);
                SDL_Flip(screen);
                SDL_Delay(2000);
            }
        }
    } else {
        // Afficher le puzzle principal
        SDL_BlitSurface(assets->puzzles[assets->current_puzzle].img, NULL, screen, &assets->puzzles[assets->current_puzzle].pos);

        // Afficher les 3 propositions du puzzle à droite
        for (int i = 0; i < 3; i++) {
            Image *prop = &assets->propositions[assets->current_puzzle][i];
            SDL_BlitSurface(prop->img, NULL, screen, &prop->pos);

            // Si la proposition est survolée, dessiner un cadre blanc autour
            if (prop->isHovered) {
                SDL_Rect border = prop->pos;
                border.x -= 2;
                border.y -= 2;
                border.w += 4;
                border.h += 4;
                SDL_Rect top = {border.x, border.y, border.w, 2};
                SDL_Rect bottom = {border.x, border.y + border.h - 2, border.w, 2};
                SDL_Rect left = {border.x, border.y, 2, border.h};
                SDL_Rect right = {border.x + border.w - 2, border.y, 2, border.h};
                SDL_FillRect(screen, &top, SDL_MapRGB(screen->format, 255, 255, 255));
                SDL_FillRect(screen, &bottom, SDL_MapRGB(screen->format, 255, 255, 255));
                SDL_FillRect(screen, &left, SDL_MapRGB(screen->format, 255, 255, 255));
                SDL_FillRect(screen, &right, SDL_MapRGB(screen->format, 255, 255, 255));
            }
        }
    }

    SDL_Flip(screen);
}

int is_mouse_over(Image *img, int mouse_x, int mouse_y) {
    return (mouse_x >= img->pos.x && mouse_x <= img->pos.x + img->pos.w &&
            mouse_y >= img->pos.y && mouse_y <= img->pos.y + img->pos.h);
}
