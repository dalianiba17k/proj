#ifndef IMAGE_H
#define IMAGE_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h> // Pour charger les PNG

// Structure pour une image
typedef struct {
    SDL_Rect pos;         // Position de l'image
    SDL_Surface *img;     // Surface de l'image
    int isHovered;        // Si la souris est au-dessus
    int is_selected;      // Si l'image est sélectionnée
} Image;

// Structure pour stocker toutes les images du jeu
typedef struct {
    Image puzzles[5];        // 5 puzzles
    Image propositions[5][3]; // 3 propositions par puzzle
    Image complete_puzzles[5]; // 5 images complètes (puzzle1c.png à puzzle5c.png)
    Image win, lose, timeout; // Résultats
    Image niveau1_2;         // Image niveau1-2.png (affichée après puzzleXc.png en cas de victoire)
    Image echouer;           // Image echouer.png (affichée après 3 défaites ou timeouts)
    int current_puzzle;      // Index du puzzle choisi
    int correct_proposition; // Index de la proposition correcte (0, 1 ou 2)
    Uint32 start_time;       // Temps de départ
    int game_over;           // État de fin de jeu
    SDL_Rect timer_bar;      // Barre de progression pour le chronomètre
    int used_puzzles[5];     // Tableau pour suivre les puzzles utilisés (0 = non utilisé, 1 = utilisé)
    int used_count;          // Nombre de puzzles utilisés
    int lose_count;          // Compteur de défaites ou timeouts (max 3)
} GameAssets;

// Fonction pour charger les images et initialiser les assets
int load_assets(GameAssets *assets);

// Fonction pour choisir un puzzle
void select_random_puzzle(GameAssets *assets);

// Fonction pour afficher le puzzle et les propositions
void display_game(SDL_Surface *screen, GameAssets *assets);

// Fonction pour vérifier si la souris est sur une image
int is_mouse_over(Image *img, int mouse_x, int mouse_y);

#endif
