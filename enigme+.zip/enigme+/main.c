#include "image.h"
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // Initialiser la génération aléatoire
    srand(time(NULL));

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Surface *screen = SDL_SetVideoMode(1600, 1200, 32, SDL_SWSURFACE); // Résolution : 1920x1080
    if (!screen) {
        printf("Erreur SDL_SetVideoMode: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    GameAssets assets = {0};
    if (!load_assets(&assets)) {
        SDL_Quit();
        return 1;
    }

    // Boucle principale pour gérer plusieurs parties
    int running = 1;
    SDL_Event event;
    int mouse_x, mouse_y;
    while (running) {
        // Sélectionner un puzzle dans l'ordre
        select_random_puzzle(&assets);
        assets.start_time = SDL_GetTicks(); // Temps de départ
        assets.game_over = 0; // Réinitialiser l'état de fin de jeu

        // Réinitialiser les propositions (is_selected et isHovered)
        for (int i = 0; i < 3; i++) {
            assets.propositions[assets.current_puzzle][i].is_selected = 0;
            assets.propositions[assets.current_puzzle][i].isHovered = 0;
        }

        // Boucle d'une partie
        int game_running = 1;
        while (game_running) {
            // Gestion des événements
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    game_running = 0;
                    running = 0;
                }
                else if (!assets.game_over && event.type == SDL_MOUSEMOTION) {
                    mouse_x = event.motion.x;
                    mouse_y = event.motion.y;
                    // Vérifier si la souris est sur une proposition
                    for (int i = 0; i < 3; i++) {
                        Image *prop = &assets.propositions[assets.current_puzzle][i];
                        prop->isHovered = is_mouse_over(prop, mouse_x, mouse_y);
                    }
                }
                else if (!assets.game_over && event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                    mouse_x = event.button.x;
                    mouse_y = event.button.y;
                    // Vérifier si une proposition est cliquée
                    for (int i = 0; i < 3; i++) {
                        Image *prop = &assets.propositions[assets.current_puzzle][i];
                        if (is_mouse_over(prop, mouse_x, mouse_y)) {
                            prop->is_selected = 1;
                            assets.game_over = 1; // Fin du jeu
                            // Vérifier si la proposition est correcte
                            if (i != assets.correct_proposition) {
                                assets.lose_count++; // Incrémenter le compteur de défaites
                            }
                        }
                    }
                }
            }

            // Vérifier le timeout
            if (!assets.game_over && (SDL_GetTicks() - assets.start_time) / 1000 >= 30) {
                assets.game_over = 1; // Fin du jeu par timeout
                assets.lose_count++; // Incrémenter le compteur de défaites/timeouts
            }

            // Afficher le jeu
            display_game(screen, &assets);

            // Si le jeu est fini
            if (assets.game_over) {
                // Si victoire (bonne proposition), quitter après affichage
                int correct = 0;
                for (int i = 0; i < 3; i++) {
                    if (assets.propositions[assets.current_puzzle][i].is_selected &&
                        i == assets.correct_proposition) {
                        correct = 1;
                        break;
                    }
                }
                if (correct) {
                    game_running = 0;
                    running = 0; // Quitter le jeu après victoire
                }
                // Si 3 défaites ou timeouts, quitter après affichage
                else if (assets.lose_count >= 3) {
                    game_running = 0;
                    running = 0; // Quitter le jeu
                }
                // Si défaite ou timeout mais moins de 3, continuer
                else {
                    game_running = 0; // Passer au puzzle suivant
                }
            }

            SDL_Delay(16); // Environ 60 FPS
        }
    }

    // Libérer les assets à la fin
    for (int i = 0; i < 5; i++) {
        SDL_FreeSurface(assets.puzzles[i].img);
        SDL_FreeSurface(assets.complete_puzzles[i].img);
        for (int j = 0; j < 3; j++) {
            SDL_FreeSurface(assets.propositions[i][j].img);
        }
    }
    SDL_FreeSurface(assets.win.img);
    SDL_FreeSurface(assets.lose.img);
    SDL_FreeSurface(assets.timeout.img);
    SDL_FreeSurface(assets.niveau1_2.img);
    SDL_FreeSurface(assets.echouer.img);
    SDL_Quit();
    return 0;
}
